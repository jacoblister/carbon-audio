/*==========================================================================*/
MODULE::IMPORT/*============================================================*/
/*==========================================================================*/

#include "framework.c"
#include "xmidi.c"
#include "audiostream.c"
#include "audiofile.c"
#include "devices.c"

/*==========================================================================*/
MODULE::INTERFACE/*=========================================================*/
/*==========================================================================*/

#define SAMPLER_CHANNELS 16
#define SAMPLER_BANKS    10

class CSampler : CDevice {
 private:
   void new(void);
   void delete(void);
   TFrameInfo frame_info;

   void diag_view(void);
   bool sample_filename_decode(const char *filename, int *channel, int *bank);
 public:
   ALIAS<"sampler">;

   CObjServer *server;

   void CSampler(CObjServer *server);

   virtual EDeviceError open(TFrameInfo *info);
   virtual EDeviceError close();
   virtual bool frame(CFrame *frame);

   void clear(void);
   bool sample_save(const char *dirname);
   bool sample_load(const char *dirname);
};

class CSamplerBank : CAudioBuffer {
 private:
   void command(EMESampleType command);
   EMESampleType playback_mode;
   bool state_playing;
   bool state_recording;
   int play_sample;
   int record_sample;
 public:
   ALIAS<"samplerBank">;
   ATTRIBUTE<bool active> {
      this->active = FALSE;             /*>>>test kludge*/
   };
   ATTRIBUTE<bool stop> {
      CSamplerBank(this).command(EMESampleType.stop);
   };
   ATTRIBUTE<bool record> {
      CSamplerBank(this).command(EMESampleType.record);
   };
   ATTRIBUTE<bool play> {
      CSamplerBank(this).command(EMESampleType.play);
   };

   void CSamplerBank(void);
};

class CSamplerChannel : CAudioStream {
 private:
   int index;
   CSamplerBank *bank_active;

   void active_set(CSamplerBank *bank);
 public:
   ALIAS<"sampChannel">;

   void CSamplerChannel(int index);
};

/*==========================================================================*/
MODULE::IMPLEMENTATION/*====================================================*/
/*==========================================================================*/

void CSampler::new(void) {
}/*CSampler::new*/

void CSampler::CSampler(CObjServer *server) {
   int i;
   CSamplerChannel *channel;

   this->server = server;

   for (i = 0; i < SAMPLER_CHANNELS; i++) {
      channel = new.CSamplerChannel(i);
      CObject(this).child_add(CObject(channel));
   }

//   CSampler(this).diag_view();
}/*CSampler::CSampler*/

void CSampler::delete(void) {
}/*CSampler::delete*/

void CSampler::diag_view(void) {
   CGLayout *layout;
//   CObjPersistent *device_tree;
   CGTree *tree;
   CGWindow *window;

   layout = new.CGLayout(0, 0, this->server, CObjPersistent(this));
   CGCanvas(layout).colour_background_set(GCOL_NONE);
   CGLayout(layout).render_set(EGLayoutRender.none);

   tree = new.CGTree(this->server, CObjPersistent(this), 0, 0, 0, 0);
   CObject(layout).child_add_front(CObject(tree));

   window = new.CGWindow("Sampler Tree", CGCanvas(layout), NULL);
   CGWindow(window).show(TRUE);
}/*CSampler::diag_view*/

EDeviceError CSampler::open(TFrameInfo *info) {
   this->frame_info = *info;

   return EDeviceError.noError;
}/*CSampler::open*/

EDeviceError CSampler::close(void) {
   return EDeviceError.noError;
}/*CSampler::close*/

bool CSampler::frame(CFrame *frame, EStreamMode mode) {
   CSamplerChannel *channel;
   int i, sample;
   CMidiEvent *event;

   for (i = 0; i < ARRAY(&frame->midi).count(); i++) {
      event = CMidiEvent(&ARRAY(&frame->midi).data()[i]);
      if (CObject(event).obj_class() == &class(CMESample)) {
         channel = CSamplerChannel(CObject(this).child_n(event->channel - 1));
         if (channel) {
            CSamplerBank(CObject(channel).child_n(CMESample(event)->bank)).command(CMESample(event)->type);
         }
      }
   }

   i = 0;
   channel = CSamplerChannel(CObject(this).child_first());
   while (channel) {
      if (channel->bank_active) {
         if (channel->bank_active->state_recording) {
            CAudioBuffer(channel->bank_active)->sampling_rate = this->frame_info.sampling_rate;
            CAudioBuffer(channel->bank_active).write(&ARRAY(&frame->audio).data()[i], frame->length);
         }
         if (channel->bank_active->state_playing) {
            BITFIELD(&frame->channel_live).set(i, FALSE);
            if (channel->bank_active->play_sample + frame->length < CAudioBuffer(channel->bank_active).length()) {
                switch (channel->bank_active->playback_mode) {
                default:
                case EMESampleType.play:
                    CAudioBuffer(channel->bank_active).extract(&ARRAY(&frame->audio).data()[i],
                                                               channel->bank_active->play_sample, frame->length);
                    channel->bank_active->play_sample += frame->length;
                    break;
                case EMESampleType.playHalf:
                    for (sample = 0; sample < frame->length; sample++) {
                       *((float *)CAudioBuffer(&ARRAY(&frame->audio).data()[i]).data_ptr(sample)) =
                          *((float *)CAudioBuffer(channel->bank_active).data_ptr(channel->bank_active->play_sample + (sample >> 1)));
                    }
                    CAudioBuffer(&ARRAY(&frame->audio).data()[i])->data_empty = FALSE;
                    CAudioBuffer(&ARRAY(&frame->audio).data()[i])->data_size = sizeof(float) * frame->length;
                    channel->bank_active->play_sample += frame->length >> 1;
                    break;
                case EMESampleType.playReverse:
                    for (sample = 0; sample < frame->length; sample++) {
                       *((float *)CAudioBuffer(&ARRAY(&frame->audio).data()[i]).data_ptr(sample)) =
                          *((float *)CAudioBuffer(channel->bank_active).data_ptr(CAudioBuffer(channel->bank_active).length() - (channel->bank_active->play_sample + (sample >> 1))));
                    }
                    CAudioBuffer(&ARRAY(&frame->audio).data()[i])->data_empty = FALSE;
                    CAudioBuffer(&ARRAY(&frame->audio).data()[i])->data_size = sizeof(float) * frame->length;
                    channel->bank_active->play_sample += frame->length >> 1;
                    break;
                }
            }
            else {
               CSamplerBank(channel->bank_active).command(EMESampleType.stop);
            }
         }
      }
      channel = CSamplerChannel(CObject(this).child_next(CObject(channel)));
      i++;
   }
   return TRUE;
}/*CSampler::frame*/

bool CSampler::sample_filename_decode(const char *filename, int *channel, int *bank) {
    if (toupper(filename[0]) != 'C')
        return FALSE;

    if (!(isdigit(filename[1]) && isdigit(filename[2])))
        return FALSE;

    *channel = ((filename[1] - '0') * 10) + (filename[2] - '0');

    if (toupper(filename[3]) != 'B')
        return FALSE;

    if (!(isdigit(filename[4]) && isdigit(filename[5])))
        return FALSE;

    *bank = ((filename[4] - '0') * 10) + (filename[5] - '0');

    return TRUE;
}/*CSampler::sample_filename_decode*/

EDeviceError CSampler::clear(void) {
  CSamplerChannel *channel;
  CSamplerBank *bank;

  channel = CSamplerChannel(CObject(this).child_first());
  while (channel) {
     bank = CSamplerBank(CObject(channel).child_first());
     while (bank) {
        if (bank->active) {
           CObjPersistent(bank).attribute_update(ATTRIBUTE<CSamplerBank,active>);
           CObjPersistent(bank).attribute_set_int(ATTRIBUTE<CSamplerBank,active>, FALSE);
           CObjPersistent(bank).attribute_update_end();
        }

        bank = CSamplerBank(CObject(channel).child_next(CObject(bank)));
     }

     channel = CSamplerChannel(CObject(this).child_next(CObject(channel)));
  }

  return EDeviceError.noError;
}/*CSampler::clear*/

bool CSampler::sample_load(const char *dirname) {
  DIR *dp;
  struct dirent *ep;
  int channel_n, bank_n;
  CSamplerChannel *channel;
  CSamplerBank *bank;
  CAudioFileWave audio_file;
  char dirpath[80], fullname[80];

  CSampler(this).clear();

  sprintf(dirpath, "%s/", dirname);

  dp = opendir (dirpath);
  if (dp != NULL) {
      while ((ep = readdir(dp))) {
         if (strcmp(ep->d_name + strlen(ep->d_name) - 4, ".wav") == 0) {
            if (CSampler(this).sample_filename_decode(ep->d_name, &channel_n, &bank_n)) {
               channel = CSamplerChannel(CObject(this).child_n(channel_n));
               bank = CSamplerBank(CObject(channel).child_n(bank_n));
               new(&audio_file).CAudioFileWave(CAudioBuffer(bank));
               CAudioBuffer(bank).data_allocate(3000000/*channel->index <= 9 ? 2000000 : (96000 * 60 * 6)*/);
               CAudioBuffer(bank).data_length_set(0);
               CAudioBuffer(bank)->data_empty = FALSE;
               sprintf(fullname, "%s/%s", dirname, ep->d_name);
               CAudioFile(&audio_file).file_load(fullname);
               CObjPersistent(bank).attribute_update(ATTRIBUTE<CSamplerBank,active>);
               bank->active = TRUE;
               CObjPersistent(bank).attribute_update_end();
               delete(&audio_file);
            }
         }
      }
      (void) closedir (dp);
    }
  else
    puts ("Couldn't open the directory.");

  return TRUE;
}/*CSampler::sample_load*/

bool CSampler::sample_save(const char *dirname) {
  CSamplerChannel *channel;
  CSamplerBank *bank;
  CString filename;
  CAudioFileWave audio_file;
  int i;

  /*>>>create sample directory if it dosn't exist */

  new(&filename).CString(NULL);
  channel = CSamplerChannel(CObject(this).child_first());
  while (channel) {
     i = 0;
     bank = CSamplerBank(CObject(channel).child_first());
     while (bank) {
        if (bank->active) {
           CString(&filename).printf("%s/C%02dB%02d.wav", dirname, channel->index, i);
           new(&audio_file).CAudioFileWave(CAudioBuffer(bank));
           CAudioFile(&audio_file).file_save(CString(&filename).string());
           delete(&audio_file);
        }

        bank = CSamplerBank(CObject(channel).child_next(CObject(bank)));
        i++;
     }

     channel = CSamplerChannel(CObject(this).child_next(CObject(channel)));
  }
  delete(&filename);

  return TRUE;
}/*CSampler::sample_save*/

void CSamplerBank::CSamplerBank(void) {
   CAudioBuffer(this).CAudioBuffer(EAudioDataType.word, 0);
}/*CSamplerBank::CSamplerBank*/

void CSamplerBank::command(EMESampleType command) {
   CSamplerChannel *channel = CSamplerChannel(CObject(this).parent());

   switch (command) {
   case EMESampleType.stop:
      channel->bank_active = NULL;
      break;
   case EMESampleType.play:
   case EMESampleType.playHalf:   
   case EMESampleType.playReverse:
   case EMESampleType.record:
      CSamplerChannel(channel).active_set(this);
      break;
   default:
      break;
   }

   CObjPersistent(this).attribute_update(ATTRIBUTE<CSamplerBank,active>);
   CObjPersistent(this).attribute_update(ATTRIBUTE<CSamplerBank,stop>);
   CObjPersistent(this).attribute_update(ATTRIBUTE<CSamplerBank,play>);
   CObjPersistent(this).attribute_update(ATTRIBUTE<CSamplerBank,record>);
   this->stop = FALSE;
//   this->play = FALSE;
//   this->record = FALSE;
   switch (command) {
   case EMESampleType.stop:
      this->state_playing   = FALSE;
      this->state_recording = FALSE;
      this->play = FALSE;
      this->record = FALSE;
      break;
   case EMESampleType.stopPlay:
      this->state_playing   = FALSE;
      this->play = FALSE;
      break;
   case EMESampleType.stopRecord:
      this->state_recording = FALSE;
      this->record = FALSE;
      break;
   case EMESampleType.play:
   case EMESampleType.playHalf:
   case EMESampleType.playReverse:
      this->playback_mode = command;
      this->state_playing = TRUE;
      this->play_sample = 0;
      this->play = TRUE;
      break;
   case EMESampleType.record:
      /*>>>better memory allocation */
      CAudioBuffer(this).data_allocate(3000000/*channel->index <= 9 ? 2000000 : (96000 * 60 * 6)*/);
      CAudioBuffer(this).data_length_set(0);
      this->active = TRUE;
      this->record = TRUE;
      this->state_recording = TRUE;
      break;
   default:
      break;
   }

   CObjPersistent(this).attribute_update_end();
}/*CSamplerBank::command*/

void CSamplerChannel::CSamplerChannel(int index) {
   int i;
   CSamplerBank *bank;

   this->index = index;

   for (i = 0; i < SAMPLER_BANKS; i++) {
      bank = new.CSamplerBank();
      CObject(this).child_add(CObject(bank));
   }
}/*CSamplerChannel*/

void CSamplerChannel::active_set(CSamplerBank *bank) {
   if (this->bank_active && this->bank_active != bank) {
      CSamplerBank(this->bank_active).command(EMESampleType.stop);
   }
   this->bank_active = bank;
}/*CSamplerChannel::active_set*/

/*==========================================================================*/
MODULE::END/*===============================================================*/
/*==========================================================================*/
