// kX kxctrl
// Copyright (c) Eugene Gavrilov, 2001-2003.
// All rights reserved

// This program is free software; you can redistribute it and/or
// modify it under the terms of the 
// EUGENE GAVRILOV KX DRIVER SOFTWARE DEVELOPMENT KIT LICENSE AGREEMENT

#if !defined(AFX_STDAFX_H__8916B216_EC7B_4C58_8989_2C23F9DDDDFD__INCLUDED_)
#define AFX_STDAFX_H__8916B216_EC7B_4C58_8989_2C23F9DDDDFD__INCLUDED_

#pragma once

#include <afx.h>
#include <afxwin.h>
#include <afxext.h>
#include <afxdtctl.h>

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <direct.h>

#endif
