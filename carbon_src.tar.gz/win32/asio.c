extern "C"
{

#include "asio.cpp"

}