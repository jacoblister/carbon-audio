/*==========================================================================*/
MODULE::IMPORT/*============================================================*/
/*==========================================================================*/

#include "framework.c"
#include "../devices.c"
#include "../xmidi.c"

/*==========================================================================*/
MODULE::INTERFACE/*=========================================================*/
/*==========================================================================*/

/*==========================================================================*/
MODULE::IMPLEMENTATION/*====================================================*/
/*==========================================================================*/

extern void CARBON_buffer_switch_notify(void);

#include <jack/jack.h>
#include <jack/midiport.h>

class CDeviceAudioJack : CDeviceAudio {
 private:
   jack_port_t *output_port[2];
   jack_port_t *input_port[2];
 public:
   void CDeviceAudioJack(void);

   virtual EDeviceError open(void);
   virtual EDeviceError close(void);
   virtual bool frame(CFrame *frame, EStreamMode mode);
};

class CDeviceMIDIJack : CDeviceMIDI {
 private:
   void new(void);
   void delete(void);
   jack_port_t *output_port;
   jack_port_t *input_port;

   byte status;
   byte expected;
   byte count;
   byte read_buf[4];
   ARRAY<TMidiEventContainer> outbuf;
 public:
   void CDeviceMIDIJack(void);

   virtual EDeviceError open(void);
   virtual EDeviceError close(void);
   virtual bool frame(CFrame *frame, EStreamMode mode);
};

class CDeviceJack : CDevice {
 private:
   void new(void);
   void delete(void);
   jack_client_t *client;
   void process(void);
   CDeviceMIDIJack dev_midi;
   CDeviceAudioJack dev_audio;
 public:
   ALIAS<"deviceJack">;

   virtual EDeviceError open(void);
   virtual EDeviceError close(void);
   virtual bool frame(CFrame *frame, EStreamMode mode);
};

void CDeviceAudioJack::CDeviceAudioJack(void) {
}/*CDeviceAudioJack::CDeviceAudioJack*/

EDeviceError CDeviceAudioJack::open(TFrameInfo *info) {
   CDeviceJack *dev_jack = CDeviceJack(CObject(this).parent());
   CDeviceAudio(this)->data_format = EAudioDataType.float;

   this->output_port[0] = jack_port_register(dev_jack->client, "out1", JACK_DEFAULT_AUDIO_TYPE, JackPortIsOutput, 0);
   this->output_port[1] = jack_port_register(dev_jack->client, "out2", JACK_DEFAULT_AUDIO_TYPE, JackPortIsOutput, 0);
   this->input_port[0] = jack_port_register(dev_jack->client, "in1", JACK_DEFAULT_AUDIO_TYPE, JackPortIsInput, 0);
   this->input_port[1] = jack_port_register(dev_jack->client, "in2", JACK_DEFAULT_AUDIO_TYPE, JackPortIsInput, 0);
   
   class:base.open(info);
   return EDeviceError.noError;
}/*CDeviceAudioJack::open*/

EDeviceError CDeviceAudioJack::close(void) {
   CDeviceJack *dev_jack = CDeviceJack(CObject(this).parent());

   class:base.close();
   
   jack_port_unregister(dev_jack->client, this->output_port[0]);
   jack_port_unregister(dev_jack->client, this->output_port[1]);
   jack_port_unregister(dev_jack->client, this->input_port[0]);
   jack_port_unregister(dev_jack->client, this->input_port[1]);

   return EDeviceError.noError;
}/*CDeviceAudioJack::close*/

bool CDeviceAudioJack::frame(CFrame *frame, EStreamMode mode) {
   int i;
   jack_default_audio_sample_t *in, *out;
   switch (mode) {
   case EStreamMode.input:
      for (i = 0; i < 2; i++) {
         in = jack_port_get_buffer(this->input_port[i], frame->length);
         memcpy(CAudioBuffer(&ARRAY(&frame->audio).data()[i]).data_pointer_get(), in,
                sizeof(jack_default_audio_sample_t) * frame->length);
         CAudioBuffer(&ARRAY(&frame->audio).data()[i])->data_empty = FALSE;
      }
      class:base.frame(frame, mode);
      break;
   case EStreamMode.output:
      class:base.frame(frame, mode);
      for (i = 0; i < 2; i++) {
         out = jack_port_get_buffer(this->output_port[i], frame->length);
         memcpy(out, CAudioBuffer(&ARRAY(&frame->audio).data()[i]).data_pointer_get(),
                sizeof(jack_default_audio_sample_t) * frame->length);
      }
      break;
   default:
      return FALSE;
   }
   return TRUE;
}/*CDeviceAudioJack::frame*/

void CDeviceMIDIJack::new(void) {
   ARRAY(&this->outbuf).new();
   }

void CDeviceMIDIJack::delete(void) {
   ARRAY(&this->outbuf).delete();
   }

void CDeviceMIDIJack::CDeviceMIDIJack(void) {
}/*CDeviceMIDIJack::CDeviceMIDIJack*/

EDeviceError CDeviceMIDIJack::open(TFrameInfo *info) {
   CDeviceJack *dev_jack = CDeviceJack(CObject(this).parent());

   this->output_port = jack_port_register(dev_jack->client, "midi-out", JACK_DEFAULT_MIDI_TYPE, JackPortIsOutput, 0);
   this->input_port = jack_port_register(dev_jack->client, "midi-in", JACK_DEFAULT_MIDI_TYPE, JackPortIsInput, 0);
   return EDeviceError.noError;
}/*CDeviceMIDIJack::open*/

EDeviceError CDeviceMIDIJack::close(void) {
   CDeviceJack *dev_jack = CDeviceJack(CObject(this).parent());
   jack_port_unregister(dev_jack->client, this->output_port);

   return EDeviceError.noError;
}/*CDeviceMIDIJack::close*/

bool CDeviceMIDIJack::frame(CFrame *frame, EStreamMode mode) {
   int write_count = 0;
   int i;
   int count;
   ARRAY<byte> outdata;
   byte* midi_buffer;
   void* port_buf;
   jack_midi_event_t read_event;
   TMidiEventContainer event;
   
   class:base.frame(frame, mode);

   if (mode == EStreamMode.input) {
      port_buf = jack_port_get_buffer(this->input_port, frame->length);
      for (i = 0; i < jack_midi_get_event_count(port_buf); i++) {
         jack_midi_event_get(&read_event, port_buf, i);
         CLEAR(&event);
         TMidiEventContainer_new(&event, read_event.buffer[0], read_event.buffer[1], read_event.buffer[2], 0);
         ARRAY(&frame->midi).item_add(event);
      }
   }
   if (mode == EStreamMode.output) {
#if 1
      for (i = 0; i < ARRAY(&frame->midi).count(); i++) {
         ARRAY(&this->outbuf).item_add(ARRAY(&frame->midi).data()[i]);
      }

      port_buf = jack_port_get_buffer(this->output_port, frame->length);
      jack_midi_clear_buffer(port_buf);
      ARRAY(&outdata).new();
      count = ARRAY(&this->outbuf).count();
      count = count < 1 ? count : 1;
      while (count != 0 && write_count < 1) {
         write_count++;
         ARRAY(&outdata).used_set(0);
         for (i = 0; i < count; i++) {
            TMidiEventContainer_encode_append(&ARRAY(&this->outbuf).data()[i], &outdata, NULL);
         }
         if (ARRAY(&outdata).count()) {
            midi_buffer = jack_midi_event_reserve(port_buf, 0, ARRAY(&outdata).count());
//            for (i = 0; i < ARRAY(&outdata).count(); i++) {
//               printf("%02x ", ARRAY(&outdata).data()[i]);
//            }
            printf("\n");
            if (midi_buffer) {
               memcpy(midi_buffer, ARRAY(&outdata).data(), ARRAY(&outdata).count());
            }
            else {
               printf("failed MIDI write count events=%d bytes=%d\n", ARRAY(&frame->midi).count(), ARRAY(&outdata).count());
            }
         }
         memcpy(ARRAY(&this->outbuf).data(), ARRAY(&this->outbuf).data() + count, (ARRAY(&this->outbuf).count() - count) * sizeof(TMidiEventContainer));
         ARRAY(&this->outbuf).used_set(ARRAY(&this->outbuf).count() - count);
     
         count = ARRAY(&this->outbuf).count();
         count = count < 1 ? count : 1;
      }
      ARRAY(&outdata).delete();
#else
      port_buf = jack_port_get_buffer(this->output_port, frame->length);
      jack_midi_clear_buffer(port_buf);
      ARRAY(&outdata).new();
      if (ARRAY(&frame->midi).count() != 0) {
         for (i = 0; i < ARRAY(&frame->midi).count(); i++) {
            TMidiEventContainer_encode_append(&ARRAY(&frame->midi).data()[i], &outdata, NULL);
         }
         if (ARRAY(&outdata).count()) {
            midi_buffer = jack_midi_event_reserve(port_buf, 0, ARRAY(&outdata).count());
//             printf("reserved=%d avail=%d\n", ARRAY(&outdata).count(), jack_midi_max_event_size(port_buf));
            if (midi_buffer) {
               memcpy(midi_buffer, ARRAY(&outdata).data(), ARRAY(&outdata).count());
            }
            else {
               printf("failed MIDI write count events=%d bytes=%d\n", ARRAY(&frame->midi).count(), ARRAY(&outdata).count());
            }
         }
      }
      ARRAY(&outdata).delete();
#endif
   }

   return TRUE;
}/*CDeviceMIDIJack::frame*/

int process(jack_nframes_t nframes, void *arg) {
   CARBON_buffer_switch_notify();
   return 0;
}

void CDeviceJack::new(void) {
   class:base.new();
   new(&this->dev_audio).CDeviceAudioJack();
   CObject(&this->dev_audio).parent_set(CObject(this));
   new(&this->dev_midi).CDeviceMIDIJack();
   CObject(&this->dev_midi).parent_set(CObject(this));
}/*CDeviceJack::new*/

void CDeviceJack::delete(void) {
   delete(&this->dev_midi);
   delete(&this->dev_audio);
   class:base.delete();
}/*CDeviceJack::delete*/

EDeviceError CDeviceJack::open(TFrameInfo *info) {
printf("jack open\n");
   CDevice(&this->dev_audio)->mixer_mode = CDevice(this)->mixer_mode;
   CDevice(&this->dev_audio)->monitor_mode = CDevice(this)->monitor_mode;
   CDevice(&this->dev_audio)->mix_down = CDevice(this)->mix_down;
   CDeviceHardware(&this->dev_audio)->mapping_mode = CDevice(this)->mapping_mode;
   CDevice(&this->dev_midi)->mixer_mode = CDevice(this)->mixer_mode;
   CDevice(&this->dev_midi)->monitor_mode = CDevice(this)->monitor_mode;
   CDevice(&this->dev_midi)->mix_down = CDevice(this)->mix_down;
   CDeviceHardware(&this->dev_midi)->mapping_mode = CDevice(this)->mapping_mode;
   
   if ((this->client = jack_client_open("carbon", JackNullOption, NULL)) == 0) {
      fprintf(stderr, "jack server not running?\n");
      return EDeviceError.deviceError;
   }
   CDevice(&this->dev_audio).open(info);
   CDevice(&this->dev_midi).open(info);
   jack_set_process_callback(this->client, process, (void *)this);
   if (jack_activate(this->client)) {
      return EDeviceError.deviceError;
   }
   return EDeviceError.noError;
}/*CDeviceJack::open*/

EDeviceError CDeviceJack::close(void) {
printf("jack close\n");
   CDevice(&this->dev_midi).close();
   CDevice(&this->dev_audio).close();
   return EDeviceError.noError;
}/*CDeviceJack::close*/

bool CDeviceJack::frame(CFrame *frame, EStreamMode mode) {
   CDevice(&this->dev_audio).frame(frame, mode);
   CDevice(&this->dev_midi).frame(frame, mode);
   return TRUE;
}/*CDeviceJack::frame*/


/*==========================================================================*/
MODULE::END/*===============================================================*/
/*==========================================================================*/
